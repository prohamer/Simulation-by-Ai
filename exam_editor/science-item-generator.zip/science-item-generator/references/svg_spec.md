# 試題 Markdown 與 SVG 圖表輸出規範 (svg_spec.md)

本規範確保產出的試題可直接貼入「國中自然素養試題編輯器 & SVG 向量圖形工作台」，正確顯示、可在畫布中編修、可列印與匯出 Word。

---

## 一、Markdown 格式

- **標題**：`#` 試卷標題、`##` 區段（如【題組閱讀材料】）、`###` 小節（如【試題】）。
- **表格**：使用 GFM 表格；表名寫在表格上方，例如 `**表(一) …**`。
- **數學式與物理量**：用 `$…$`（行內）或 `$$…$$`（獨立一行）。單位放在 `\text{}` 中，例如 `$15.0\text{ cm}$`、`$F = ma$`。
- **題號與選項**：
  ```
  **1.（認知目標標籤）**
  題幹文字……
  (A) 選項一
  (B) 選項二
  (C) 選項三
  (D) 選項四
  ```
  每個選項獨立一行（編輯器會保留換行）。
- **SVG 前後各空一行**，不要直接接在文字或 `---` 之後。
- 粗體 `**…**` 可直接用在中文與括號旁（例如：如**表(一)**所示）。

---

## 二、SVG 根元素

```html
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 650 420" width="100%" style="max-width:650px;background-color:#ffffff;">
```

- **必須有 `viewBox`**，寬高建議 650 × 420（橫式坐標圖）或 650 × 300（示意圖、流程圖）。
- `width="100%"` 加 `max-width`，**不要寫 `height="auto"`**（不是合法屬性）。
- 背景用根元素的 `style`，不要另外放一個全幅白色 `<rect>`（在編輯器中會變成可被誤選的物件）。

---

## 三、可用與避免的元素

| 可用 | 避免 | 原因 |
| :--- | :--- | :--- |
| `line`、`polyline`、`polygon`、`rect`、`circle`、`ellipse`、`path`、`text`、`g` | `marker`（箭頭標記） | 編輯器只能把 `line` 上的 marker 轉成三角形；`path` 上的 marker 會遺失 |
| 屬性寫法：`fill="…"`、`stroke="…"`、`font-size="…"` | `<style>` 與 `class` | 畫布編輯器對 CSS 類別支援不完整 |
| `transform="translate(x, y)"` | `foreignObject`、`<image>`、濾鏡、漸層、`<use>` | 無法編輯或無法匯出 |
| 單行 `text` | 多層 `tspan` | 多層 tspan 在編輯器中位置容易跑掉 |

**箭頭**：直線＋實心三角形 `polygon`，例如 x 軸箭頭：
```html
<line x1="80" y1="360" x2="612" y2="360" stroke="#1a202c" stroke-width="2" />
<polygon points="620,360 607,354 607,366" fill="#1a202c" />
```

**文字**：每個 `text`（或其外層 `g`）都要寫明 `font-family`、`font-size`、`fill`；需要置中或靠右時用 `text-anchor="middle"`／`"end"`。
- 中文：`font-family="Microsoft JhengHei, PingFang TC, Noto Sans TC, sans-serif"`
- 數字刻度：`font-family="Times New Roman, serif"`

**id**：若必須使用 id，請取有意義且不重複的名稱（編輯器預覽時會自動加前綴避免衝突）。

---

## 四、坐標圖繪製規則

1. **先定換算公式，再算點位**。例：繪圖區 x 從 80 到 580 px 代表 0～100 gw，則 `x = 80 + 5 × F`；y 從 360 到 60 px 代表 0～20 cm，則 `y = 360 − 15 × L`。所有資料點、線段端點、刻度都用公式算出，**不可目測**。
2. **坐標軸**：標明物理量與單位，例如 `總長度 L (cm)`、`時間 t (s)`；原點標 0；刻度間距一致。
3. **網格線**：淺灰 `#e2e8f0`、線寬 1，畫在資料之前（下層）。
4. **多組數據須黑白可辨**：同時用不同線型（實線、`stroke-dasharray="8,4"` 虛線）與不同點形（圓點、方塊、三角形），不可只靠顏色區分。
5. **圖例**放在不遮住資料的空白區，外框白底灰邊。
6. **圖名**放在 SVG 頂端置中，例如 `圖(一) 彈簧總長度與懸掛物重的關係`。
7. **不可在圖中標註答案或解題提示**（例如「A 車斜率最大」「交點代表伸長量相同」）。
8. 曲線用 `path` 時，起點、終點、轉折點與表格數據必須一致；趨勢須符合科學意義。

---

## 五、建議色彩

| 用途 | 色碼 |
| :--- | :--- |
| 主要文字、坐標軸 | `#1a202c` |
| 次要文字、刻度 | `#2d3748` |
| 網格線 | `#e2e8f0` |
| 圖例外框 | `#a0aec0` |
| 數據 1（藍） | `#2b6cb0` |
| 數據 2（紅） | `#c53030` |
| 數據 3（綠） | `#2f855a` |
| 數據 4（灰） | `#4a5568` |

---

## 六、坐標圖骨架範本

```html
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 650 420" width="100%" style="max-width:650px;background-color:#ffffff;">
  <text x="325" y="24" font-size="16" font-weight="bold" fill="#1a202c" text-anchor="middle" font-family="Microsoft JhengHei, PingFang TC, Noto Sans TC, sans-serif">圖(一) 〔圖名〕</text>
  <g stroke="#e2e8f0" stroke-width="1">
    <!-- 水平、垂直網格線，座標由換算公式計算 -->
  </g>
  <line x1="80" y1="360" x2="612" y2="360" stroke="#1a202c" stroke-width="2" />
  <polygon points="620,360 607,354 607,366" fill="#1a202c" />
  <line x1="80" y1="360" x2="80" y2="42" stroke="#1a202c" stroke-width="2" />
  <polygon points="80,34 74,47 86,47" fill="#1a202c" />
  <g font-size="12" fill="#2d3748" text-anchor="end" font-family="Times New Roman, serif">
    <!-- y 軸刻度：x="70"，y = 刻度位置 + 4 -->
  </g>
  <g font-size="12" fill="#2d3748" text-anchor="middle" font-family="Times New Roman, serif">
    <!-- x 軸刻度：y="380" -->
  </g>
  <text x="92" y="44" font-size="13" font-weight="bold" fill="#1a202c" font-family="Microsoft JhengHei, PingFang TC, Noto Sans TC, sans-serif">〔y 軸物理量〕 (單位)</text>
  <text x="620" y="402" font-size="13" font-weight="bold" fill="#1a202c" text-anchor="end" font-family="Microsoft JhengHei, PingFang TC, Noto Sans TC, sans-serif">〔x 軸物理量〕 (單位)</text>
  <!-- 數據線、數據點、圖例 -->
</svg>
```

完整實例請見 `sample_item.md`。

# 範例題組：彈簧的伸長量（格式與品質基準）

> 本檔為完整範例，示範閱讀材料、表格、SVG 坐標圖、試題、命題卡的格式。數據均依「甲：原長 10.0 cm、每 20 gw 伸長 1.0 cm；乙：原長 8.0 cm、每 20 gw 伸長 2.0 cm」推算，圖中點位依 x = 80 + 5F、y = 360 − 15L 換算。

---

## 試題本文


## 【題組閱讀材料】

**閱讀下列短文與實驗數據，回答第 1. 至 3. 題：**

小美想比較兩條不同彈簧的性質。她將彈簧甲、乙分別固定在鐵架上，在下端依序懸掛不同重量的砝碼，待彈簧靜止後，以直尺測量彈簧的總長度，結果如**表(一)**與**圖(一)**所示。實驗過程中，兩條彈簧均未超過彈性限度。

**表(一) 彈簧總長度與懸掛物重的關係**

| 懸掛物重 (gw) | 0 | 20 | 40 | 60 | 80 | 100 |
| :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| 彈簧甲總長度 (cm) | 10.0 | 11.0 | 12.0 | 13.0 | 14.0 | 15.0 |
| 彈簧乙總長度 (cm) | 8.0 | 10.0 | 12.0 | 14.0 | 16.0 | 18.0 |

<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 650 420" width="100%" style="max-width:650px;background-color:#ffffff;">
  <text x="325" y="24" font-size="16" font-weight="bold" fill="#1a202c" text-anchor="middle" font-family="Microsoft JhengHei, PingFang TC, Noto Sans TC, sans-serif">圖(一) 彈簧總長度與懸掛物重的關係</text>
  <g stroke="#e2e8f0" stroke-width="1">
    <line x1="80" y1="330" x2="580" y2="330" />
    <line x1="80" y1="300" x2="580" y2="300" />
    <line x1="80" y1="270" x2="580" y2="270" />
    <line x1="80" y1="240" x2="580" y2="240" />
    <line x1="80" y1="210" x2="580" y2="210" />
    <line x1="80" y1="180" x2="580" y2="180" />
    <line x1="80" y1="150" x2="580" y2="150" />
    <line x1="80" y1="120" x2="580" y2="120" />
    <line x1="80" y1="90" x2="580" y2="90" />
    <line x1="80" y1="60" x2="580" y2="60" />
    <line x1="180" y1="60" x2="180" y2="360" />
    <line x1="280" y1="60" x2="280" y2="360" />
    <line x1="380" y1="60" x2="380" y2="360" />
    <line x1="480" y1="60" x2="480" y2="360" />
    <line x1="580" y1="60" x2="580" y2="360" />
  </g>
  <line x1="80" y1="360" x2="612" y2="360" stroke="#1a202c" stroke-width="2" />
  <polygon points="620,360 607,354 607,366" fill="#1a202c" />
  <line x1="80" y1="360" x2="80" y2="42" stroke="#1a202c" stroke-width="2" />
  <polygon points="80,34 74,47 86,47" fill="#1a202c" />
  <g font-size="12" fill="#2d3748" text-anchor="end" font-family="Times New Roman, serif">
    <text x="70" y="364">0</text>
    <text x="70" y="334">2</text>
    <text x="70" y="304">4</text>
    <text x="70" y="274">6</text>
    <text x="70" y="244">8</text>
    <text x="70" y="214">10</text>
    <text x="70" y="184">12</text>
    <text x="70" y="154">14</text>
    <text x="70" y="124">16</text>
    <text x="70" y="94">18</text>
    <text x="70" y="64">20</text>
  </g>
  <g font-size="12" fill="#2d3748" text-anchor="middle" font-family="Times New Roman, serif">
    <text x="80" y="380">0</text>
    <text x="180" y="380">20</text>
    <text x="280" y="380">40</text>
    <text x="380" y="380">60</text>
    <text x="480" y="380">80</text>
    <text x="580" y="380">100</text>
  </g>
  <text x="92" y="44" font-size="13" font-weight="bold" fill="#1a202c" font-family="Microsoft JhengHei, PingFang TC, Noto Sans TC, sans-serif">總長度 L (cm)</text>
  <text x="620" y="402" font-size="13" font-weight="bold" fill="#1a202c" text-anchor="end" font-family="Microsoft JhengHei, PingFang TC, Noto Sans TC, sans-serif">懸掛物重 F (gw)</text>
  <line x1="80" y1="210" x2="580" y2="135" stroke="#2b6cb0" stroke-width="2.5" />
  <line x1="80" y1="240" x2="580" y2="90" stroke="#c53030" stroke-width="2.5" stroke-dasharray="8,4" />
  <g fill="#2b6cb0">
    <circle cx="80" cy="210" r="4.5" />
    <circle cx="180" cy="195" r="4.5" />
    <circle cx="280" cy="180" r="4.5" />
    <circle cx="380" cy="165" r="4.5" />
    <circle cx="480" cy="150" r="4.5" />
    <circle cx="580" cy="135" r="4.5" />
  </g>
  <g fill="#c53030">
    <rect x="76" y="236" width="8" height="8" />
    <rect x="176" y="206" width="8" height="8" />
    <rect x="276" y="176" width="8" height="8" />
    <rect x="376" y="146" width="8" height="8" />
    <rect x="476" y="116" width="8" height="8" />
    <rect x="576" y="86" width="8" height="8" />
  </g>
  <g transform="translate(100, 72)" font-size="13" font-family="Microsoft JhengHei, PingFang TC, Noto Sans TC, sans-serif">
    <rect x="0" y="0" width="150" height="58" fill="#ffffff" stroke="#a0aec0" stroke-width="1" rx="4" />
    <line x1="12" y1="19" x2="50" y2="19" stroke="#2b6cb0" stroke-width="2.5" />
    <circle cx="31" cy="19" r="4.5" fill="#2b6cb0" />
    <text x="60" y="23" fill="#1a202c">彈簧甲</text>
    <line x1="12" y1="40" x2="50" y2="40" stroke="#c53030" stroke-width="2.5" stroke-dasharray="8,4" />
    <rect x="27" y="36" width="8" height="8" fill="#c53030" />
    <text x="60" y="44" fill="#1a202c">彈簧乙</text>
  </g>
</svg>

---

### 【試題】

**1.（圖表判讀）**
依據圖(一)，兩條彈簧懸掛相同物重時，在物重為多少時兩彈簧的總長度相同？
(A) 0 gw
(B) 20 gw
(C) 40 gw
(D) 60 gw

**2.（彈簧伸長量的應用）**
將一個重量未知的物體掛在彈簧乙下端，靜止後彈簧乙的總長度為 $15.0\text{ cm}$。此物體的重量為下列何者？
(A) 70 gw
(B) 75 gw
(C) 140 gw
(D) 150 gw

**3.（科學解釋）**
關於彈簧甲、乙的敘述，下列何者正確？
(A) 受相同外力時，彈簧甲的伸長量比彈簧乙大
(B) 彈簧乙的伸長量 $\Delta x$ 與所受外力 $F$ 成正比
(C) 兩條彈簧的總長度 $L$ 都與所受外力 $F$ 成正比
(D) 圖(一)中兩直線的交點，代表此時兩條彈簧的伸長量相同

---

### 【參考答案與解析】

**答案：** 1.(C)　2.(A)　3.(B)

1. 由表(一)，物重 $40\text{ gw}$ 時兩彈簧總長度皆為 $12.0\text{ cm}$，即圖中兩直線的交點。
2. 彈簧乙原長 $8.0\text{ cm}$，每增加 $20\text{ gw}$ 伸長 $2.0\text{ cm}$。伸長量 $\Delta x = 15.0 - 8.0 = 7.0\text{ cm}$，故物重 $F = 7.0 \times 10 = 70\text{ gw}$。選 (C) 者誤用了彈簧甲的比例；選 (D) 者誤把總長度當成伸長量。
3. (A) 相同外力下，彈簧乙的伸長量較大；(C) 與外力成正比的是伸長量，而非總長度；(D) 交點代表總長度相同，此時甲伸長 $2.0\text{ cm}$、乙伸長 $4.0\text{ cm}$，伸長量並不相同。

---

## 命題卡

| 題號 | 答案 | 認知層次 | 學習內容（代碼待教師確認） |
| :---: | :---: | :--- | :--- |
| 1 | (C) | 圖表直讀 | 力與彈簧的伸長量 |
| 2 | (A) | 定量應用 | 力與彈簧的伸長量 |
| 3 | (B) | 概念辨析、圖表推論 | 力與彈簧的伸長量；科學探究（數據解讀） |

**誘答設計對應迷思**
- 第 2 題 (C) 140 gw：誤用彈簧甲的比例（每 20 gw 伸長 1 cm）。
- 第 2 題 (D) 150 gw：把總長度 15.0 cm 當成伸長量。
- 第 3 題 (C)：「總長度與外力成正比」是最常見的迷思，正確應為伸長量與外力成正比。
- 第 3 題 (D)：把兩直線交點（總長度相同）誤解為伸長量相同。

**自我檢核結果**
- 數據：表格、圖形點位、解析計算三者一致（已重算）。
- 每題單一正解；圖中無答案提示；三題相互獨立。
- 選項長度相近；正解位置為 C、A、B，已分散。
- SVG 未使用 marker、class 或 height="auto"，可在編輯器中編修。
